class NearbyAvailableDrivers {
  String? key;
  double? latitude;
  double? longitude;

  NearbyAvailableDrivers({
    this.key,
    this.latitude,
    this.longitude,
  });
}
