class Category {
  String? title;
  String? type;
  String? image;

  Category({this.title,this.type,this.image});
}