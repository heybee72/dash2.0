import 'package:flutter/material.dart';

class Item with ChangeNotifier {
  final String itemId;
  final String catId;
  final String storeId;
  final String title;
  final String description;
  final String price;
  final String image;
  final bool isAvailable;

  Item(
      {required this.itemId,
      required this.catId,
      required this.storeId,
      required this.title,
      required this.description,
      required this.price,
      required this.image,
      required this.isAvailable});
}

class ItemProvider with ChangeNotifier {
  List<Item> _items = [
    Item(
        catId: 'cat1',
        itemId: 'item1',
        storeId: 'store1',
        title: '5-1n 2',
        description:
            'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
        price: '3500',
        image: 'assets/category_food.jpg',
        isAvailable: true),
    Item(
        catId: 'cat1',
        itemId: 'item1',
        storeId: 'store1',
        title: '5-1n 3',
        description:
            'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',
        price: '1500',
        image: 'assets/category_food.jpg',
        isAvailable: true),
  ];

  List<Item> get items {
    return _items;
  }

  List<Item> fetchItemsByCategory(String catId) {
    List<Item> itemList = _items
        .where(
            (element) => element.storeId.toLowerCase() == catId.toLowerCase())
        .toList();
    return itemList;
  }

  List<Item> fetchItemsByStore(String storeId) {
    List<Item> itemList = _items
        .where(
            (element) => element.storeId.toLowerCase() == storeId.toLowerCase())
        .toList();
    return itemList;
  }

  Item getById(String itemId) {
    return _items.firstWhere((element) => element.itemId == itemId);
  }

  // void addItem(Item item) {
  //   _items.add(item);
  //   notifyListeners();
  // }

  // void updateItem(Item item) {
  //   final itemIndex = _items.indexWhere((item) => item.itemId == item.itemId);
  //   _items[itemIndex] = item;
  //   notifyListeners();
  // }

  // void deleteItem(String id) {
  //   _items.removeWhere((item) => item.itemId == id);
  //   notifyListeners();
  // }
}
