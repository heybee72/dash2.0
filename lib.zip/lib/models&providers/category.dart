import 'package:flutter/material.dart';

class Category with ChangeNotifier {
  final String catId;
  final String storeId;
  final String itemName;
  final bool isAvailable;

  Category(
      {required this.catId,
      required this.storeId,
      required this.itemName,
      required this.isAvailable});
}

class CategoryProvider with ChangeNotifier {
  List<Category> _categories = [
    Category(
      catId: 'cat1',
      storeId: 'store1',
      itemName: "combo Meal 1",
      isAvailable: true,
    ),
    Category(
      catId: 'cat2',
      storeId: 'store1',
      itemName: "combo Meal 2",
      isAvailable: true,
    ),
    Category(
      catId: 'cat3',
      storeId: 'store1',
      itemName: "combo Meal 3",
      isAvailable: true,
    ),
    Category(
      catId: 'cat4',
      storeId: 'store1',
      itemName: "combo Meal 4",
      // items: [{"title":"qwert","price":"123"},{"title":"qwert","price":"123"},{"title":"qwert","price":"123"},{"title":"qwert","price":"123"},],
      isAvailable: true,
    ),
  ];

  List<Category> categories() {
    return _categories;
  }

  List<Category> fetchCategoriesByStore(String storeId) {
    List<Category> categoryList = _categories
        .where(
            (element) => element.storeId.toLowerCase() == storeId.toLowerCase())
        .toList();
    return categoryList;
  }
}
