import 'package:flutter/material.dart';

class Cart with ChangeNotifier {
  final String cartId;
  final String itemId;
  final String title;
  final String imageUrl;
  final double price;
  final int quantity;

  Cart({
    required this.cartId,
    required this.itemId,
    required this.title,
    required this.imageUrl,
    required this.price,
    required this.quantity,
  });
}

class CartProvider with ChangeNotifier {
  Map<String, Cart> _cartList = {};

  Map<String, Cart> get cartList {
    return _cartList;
  }

  double get totalAmount {
    double total = 0.0;
    _cartList.forEach((key, value) {
      total += value.price * value.quantity;
    });
    return total;
  }

  void addToCart(String pId, String title, String itemId, String imageUrl,
      double price, int quantity) {
    if (_cartList.containsKey(pId)) {
      _cartList.update(
        pId,
        (value) => Cart(
          cartId: value.cartId,
          title: value.title,
          imageUrl: value.imageUrl,
          price: value.price,
          quantity: value.quantity,
          itemId: value.itemId,
        ),
      );

      print(_cartList[0]);
    } else {
      _cartList.putIfAbsent(
        pId,
        () => Cart(
          cartId: DateTime.now().toIso8601String(),
          title: title,
          imageUrl: imageUrl,
          price: price,
          quantity: 1,
          itemId: itemId,
        ),
      );
    }
    notifyListeners();
  }

  void decrementCartProductQuantity(
    String pId,
    String title,
    String itemId,
    String imageUrl,
    double price,
  ) {
    if (_cartList.containsKey(pId)) {
      _cartList.update(
        pId,
        (value) => Cart(
          cartId: value.cartId,
          title: value.title,
          imageUrl: value.imageUrl,
          price: value.price,
          quantity: value.quantity - 1,
          itemId: itemId,
        ),
      );
    }
    notifyListeners();
  }

  // int get itemCount {
  //   return _items.length;
  // }

  void removeItem(String pId) {
    _cartList.remove(pId);
    notifyListeners();
  }

  void clearCart() {
    _cartList.clear();
    notifyListeners();
  }
}
