// class Store {
//   double? longitude;
//   double? latitude;
//   String? sId;
//   int? categoryCount;
//   String? name;
//   String? category;
//   String? sCityId;
//   String? sStoreTypeId;
//   String? deliveryTime;
//   String? image;
//   String? address;

//   Store({
//     this.longitude,
//     this.latitude,
//     this.sId,
//     this.categoryCount,
//     this.name,
//     this.category,
//     this.sCityId,
//     this.sStoreTypeId,
//     this.deliveryTime,
//     this.image,
//     this.address,
//   });

//   get tags => null;
// }
