import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dash_user_app/dataHandler/app_data.dart';
import 'package:dash_user_app/global/global.dart';
import 'package:dash_user_app/models&providers/store.dart';
import 'package:dash_user_app/new_models/data_class.dart';
import 'package:dash_user_app/new_models/store_model.dart';
import 'package:dash_user_app/new_provider/store_provider.dart';
import 'package:dash_user_app/screens/innerScreens/choose_category.dart';
import 'package:dash_user_app/screens/innerScreens/select_location.dart';
import 'package:dash_user_app/screens/innerScreens/store_details.dart';
import 'package:dash_user_app/utils/constants.dart';
import 'package:dash_user_app/utils/set_pref.dart';
import 'package:dash_user_app/widgets/empty_cart.dart';
import 'package:dash_user_app/widgets/no_delivery.dart';
import 'package:dash_user_app/widgets/select_location.dart';
import 'package:dash_user_app/widgets/store_lists.dart';
import 'package:dash_user_app/widgets/store_top_bar.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:geocoding/geocoding.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class Stores extends StatefulWidget {
  Stores({Key? key}) : super(key: key);

  @override
  _StoresState createState() => _StoresState();
}

class _StoresState extends State<Stores> {
  getStoreData() async {
    var response = await http.get(
      Uri.parse(
          'https://dash.toptechng.com/api/user/fetchStores/8.47502833358598/4.511619362178172/food'),
    );
    // var request = http.MultipartRequest(
    //     'GET',
    //     Uri.parse(
    //         'https://dash.toptechng.com/api/user/fetchStores/8.47502833358598/4.511619362178172/food'));

    // http.StreamedResponse response = await request.send();
    var jsonData = jsonDecode(response.body);
    // final userdata = new Map<String, dynamic>.from(response['body']);

    List<Store> stores = [];

    for (var data in jsonData) {
      Store store = Store(
        data['uid'],
        data['storeName'],
        data['storeImage'],
        data['storeDescription'],
        data['storeLocation'],
      );
      stores.add(store);
    }
    print("this is the store length");
    print(stores.length);
    return stores;
  }

  @override
  String category = '';
  String selected_location = '';
  double selected_lat = 0.0;
  double selected_lng = 0.0;

  getSharedPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? prefCat = prefs.getString('prefCat');
    // String? selected_location = prefs.getString('selected_location');
    // double? selected_lat = prefs.getDouble('selected_lat');
    // double? selected_lng = prefs.getDouble('selected_lng');

    if (prefCat != null) {
      setState(() {
        category = prefCat;
      });
    } else {
      setState(() {
        category = 'Select Category';
      });
    }
  }

  void fetchStore() async {
    var request = http.MultipartRequest(
        'GET',
        Uri.parse(
            'http://127.0.0.1:8000/api/user/fetchStores/8.47502833358598/4.511619362178172/food'));

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      print("this is the status code for 200");
    } else {
      print(response.reasonPhrase);
    }
  }

  initState() {
    super.initState();
    getSharedPreferences();
  }

  @override
  Widget build(BuildContext context) {
    selected_lat =
        Provider.of<AppData>(context).deliveryLocation?.latitude ?? 0.0;
    selected_lng =
        Provider.of<AppData>(context).deliveryLocation?.longitude ?? 0.0;

    final storeModel = Provider.of<StoreModels>(context, listen: false)
        .fetchAndSetStore(cat: category, lat: selected_lat, lng: selected_lng);

    // Future getProjectDetails() async {
    //   var request = http.MultipartRequest(
    //       'GET',
    //       Uri.parse(
    //           'http://127.0.0.1:8000/api/user/fetchStores/8.47502833358598/4.511619362178172/food'));

    //   http.StreamedResponse response = await request.send();

    //   if (response.statusCode == 200) {
    //     print(await response.stream.bytesToString());
    //   } else {
    //     print(response.reasonPhrase);
    //   }
    // }

    // Widget fetchStore() {
    //   return FutureBuilder(
    //     builder: (context, AsyncSnapshot storeSnap) {
    //       if (storeSnap.connectionState == ConnectionState.none) {
    //         print('project snapshot data is: ${storeSnap.data}');
    //         return Container();
    //       } else if (storeSnap.connectionState == ConnectionState.waiting) {
    //         return Center(
    //           child: CircularProgressIndicator(),
    //         );
    //       } else if (storeSnap.connectionState == ConnectionState.done) {
    //         return ListView.builder(
    //           itemCount: storeSnap.data!.length,
    //           itemBuilder: (context, index) {
    //             // storeSnap.data![index].storeName;
    //             return Column(
    //               children: <Widget>[
    //                 Container(
    //                   margin:
    //                       EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
    //                   width: MediaQuery.of(context).size.width,
    //                   height: 150,
    //                   child: ClipRRect(
    //                     borderRadius: BorderRadius.circular(5),
    //                     child: Stack(
    //                       children: <Widget>[
    //                         Image.network(
    //                           '${storeSnap.data![index].storeImage}',
    //                           fit: BoxFit.cover,
    //                           width: MediaQuery.of(context).size.width,
    //                         ),
    //                         Opacity(
    //                           opacity: .6,
    //                           child: Container(
    //                             color: Constants.primary_color,
    //                           ),
    //                         ),
    //                         Center(
    //                           heightFactor: 5,
    //                           child: Padding(
    //                             padding: const EdgeInsets.only(
    //                                 left: 16.0, right: 16.0),
    //                             child: Text(
    //                               "${storeSnap.data![index].storeName}",
    //                               overflow: TextOverflow.ellipsis,
    //                               style: TextStyle(
    //                                   color: Colors.white,
    //                                   fontWeight: FontWeight.w500,
    //                                   fontSize: 18.0),
    //                             ),
    //                           ),
    //                         ),
    //                         Center(
    //                           heightFactor: 35,
    //                           child: Padding(
    //                             padding: const EdgeInsets.only(top: 16.0),
    //                             child: Row(
    //                                 mainAxisAlignment: MainAxisAlignment.center,
    //                                 children: []),
    //                           ),
    //                         ),
    //                         Positioned(
    //                           bottom: 5.0,
    //                           right: 10.0,
    //                           child: Text(
    //                             "30-35 min(s)",
    //                             style: TextStyle(
    //                               color: Colors.white,
    //                               fontSize: 12,
    //                               fontWeight: FontWeight.w500,
    //                             ),
    //                           ),
    //                         )
    //                       ],
    //                     ),
    //                   ),
    //                 )
    //               ],
    //             );
    //           },
    //         );
    //       } else {
    //         return Container();
    //       }
    //     },
    //     future: getProjectDetails(),
    //   );
    // }

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: 50.0),
        child: RefreshIndicator(
          onRefresh: () async {
            print("refreshing");
            await Provider.of<StoreModels>(context, listen: false)
                .fetchAndSetStore(
                    cat: category, lat: selected_lat, lng: selected_lng);
          },
          child: Column(
            children: [
              TopBar(category: category),
              Expanded(
                child: Container(
                  child: Center(
                    child: ElevatedButton(
                      child: Text("click"),
                      onPressed: () {
                        getStoreData();
                      },
                    ),
                  ),
                ),
                // child: Provider.of<AppData>(context).deliveryLocation == null
                //     ? SelectLocation()
                //     : storeModel == 0
                //         ? NoDelivery()
                //         : fetchStore(),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class Store {
  final String uid, storeName, storeImage, storeDescription, storeLocation;

  Store(this.uid, this.storeName, this.storeImage, this.storeDescription,
      this.storeLocation);
  // String storeName;
  // String storeEmail;
  // String storePhone;
  // double lat;
  // double lng;
  // String storeImage;
  // String storeLocation;
  // String status;
  // String storeTags;
  // String category;
  // double distance;
}
